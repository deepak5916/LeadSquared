﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CardGame
{
    class Program
    {
        static Queue<Card> cards;
        public static void Main(string[] args)
        {
            cards = CreateCards();
            GameCase();
        }

        public static void GameCase()
        {
            do
            {
                int n = 0;
                Console.WriteLine("Please select an option to play");
                n = Convert.ToInt32(Console.ReadLine());

                if (cards.Count < 1)
                {
                    Console.WriteLine("No card in the Deck , Please restart the game");
                    return;
                }

                if (n == 1)
                {
                    Card card = ReturnCard();
                    Console.WriteLine("Card Played = {0} ", card.DisplayName);
                }
                else if(n==2)
                {
                    cards = DeckCreator.Shuffle(cards);
                    Console.WriteLine("Card Shuffled");
                }
                else if( n == 3)
                {
                     RestartGame();
                     Console.WriteLine("Game Restarted");
                }

            } while (true);
        }

        private static void RestartGame()
        {
            cards = new Queue<Card>();
            cards = CreateCards();
        }

        private static Queue<Card> CreateCards()
        {
            Queue<Card> cards = new Queue<Card>();
            for (int i = 2; i <= 14; i++)
            {
                foreach (Suit suit in Enum.GetValues(typeof(Suit)))
                {
                    cards.Enqueue(new Card()
                    {
                        Suit = suit,
                        Value = i,
                        DisplayName = GetShortName(i, suit)
                    });
                }
            }
            return DeckCreator.Shuffle(cards);
        }

        private static Card ReturnCard()
        {
            Card result = cards.ElementAt(0);
            cards.Dequeue();
            return result; 
        }

        private static string GetShortName(int value, Suit suit)
        {
            string valueDisplay = "";
            if (value >= 2 && value <= 10)
            {
                valueDisplay = value.ToString();
            }
            else if (value == 11)
            {
                valueDisplay = "J";
            }
            else if (value == 12)
            {
                valueDisplay = "Q";
            }
            else if (value == 13)
            {
                valueDisplay = "K";
            }
            else if (value == 14)
            {
                valueDisplay = "A";
            }

            return valueDisplay + Enum.GetName(typeof(Suit), suit)[0];
        }
    }
}
